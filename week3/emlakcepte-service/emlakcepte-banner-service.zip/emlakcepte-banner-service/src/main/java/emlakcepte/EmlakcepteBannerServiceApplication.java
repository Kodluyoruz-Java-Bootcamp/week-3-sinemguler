package emlakcepte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmlakcepteBannerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmlakcepteBannerServiceApplication.class, args);
	}

}
